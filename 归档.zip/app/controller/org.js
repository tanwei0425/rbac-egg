/*
 * @Descripttion:
 * @Author: tanwei
 * @Date: 2020-07-01 13:58:10
 * @LastEditors: tanwei
 * @LastEditTime: 2020-07-22 08:50:30
 * @FilePath: /egg/admin/app/controller/org.js
 */
'use strict';

const Controller = require('egg').Controller;
class OrgController extends Controller {
    // async index() {
    //     const { ctx } = this;
    //     const res = await ctx.service.org.index();
    //     ctx.helper.render(200, res);
    // }
}

module.exports = OrgController;
