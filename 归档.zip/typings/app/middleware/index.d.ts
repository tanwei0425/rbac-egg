// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuthCheckApi = require('../../../app/middleware/authCheckApi');
import ExportDecrypt = require('../../../app/middleware/decrypt');
import ExportJwtVerify = require('../../../app/middleware/jwtVerify');
import ExportParamDataFormat = require('../../../app/middleware/paramDataFormat');

declare module 'egg' {
  interface IMiddleware {
    authCheckApi: typeof ExportAuthCheckApi;
    decrypt: typeof ExportDecrypt;
    jwtVerify: typeof ExportJwtVerify;
    paramDataFormat: typeof ExportParamDataFormat;
  }
}
