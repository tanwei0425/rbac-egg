// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportApi = require('../../../app/controller/api');
import ExportAuth = require('../../../app/controller/auth');
import ExportCommon = require('../../../app/controller/common');
import ExportElement = require('../../../app/controller/element');
import ExportMenu = require('../../../app/controller/menu');
import ExportOrg = require('../../../app/controller/org');
import ExportRole = require('../../../app/controller/role');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    api: ExportApi;
    auth: ExportAuth;
    common: ExportCommon;
    element: ExportElement;
    menu: ExportMenu;
    org: ExportOrg;
    role: ExportRole;
    user: ExportUser;
  }
}
