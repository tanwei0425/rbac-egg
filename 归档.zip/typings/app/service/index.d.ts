// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportApi = require('../../../app/service/api');
import ExportCommon = require('../../../app/service/common');
import ExportDict = require('../../../app/service/dict');
import ExportElement = require('../../../app/service/element');
import ExportMenu = require('../../../app/service/menu');
import ExportOrg = require('../../../app/service/org');
import ExportPermission = require('../../../app/service/permission');
import ExportRole = require('../../../app/service/role');
import ExportRolePermission = require('../../../app/service/rolePermission');
import ExportSystemTheme = require('../../../app/service/systemTheme');
import ExportUser = require('../../../app/service/user');
import ExportUserRole = require('../../../app/service/userRole');

declare module 'egg' {
  interface IService {
    api: AutoInstanceType<typeof ExportApi>;
    common: AutoInstanceType<typeof ExportCommon>;
    dict: AutoInstanceType<typeof ExportDict>;
    element: AutoInstanceType<typeof ExportElement>;
    menu: AutoInstanceType<typeof ExportMenu>;
    org: AutoInstanceType<typeof ExportOrg>;
    permission: AutoInstanceType<typeof ExportPermission>;
    role: AutoInstanceType<typeof ExportRole>;
    rolePermission: AutoInstanceType<typeof ExportRolePermission>;
    systemTheme: AutoInstanceType<typeof ExportSystemTheme>;
    user: AutoInstanceType<typeof ExportUser>;
    userRole: AutoInstanceType<typeof ExportUserRole>;
  }
}
